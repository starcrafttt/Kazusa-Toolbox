﻿$(document).ready(function () {
    Buildtd();
    
    setInterval(roldRadTd, 300);
});
var tdnum = 0;//总td数量

//随机数
function RandomNumBoth(Min, Max) {
    var Range = Max - Min;
    var Rand = Math.random();
    var num = Min + Math.round(Rand * Range); //四舍五入
    return num;
}
//随机变色
function roldRadTd() {
    var dombatd = $(".batd");
    dombatd.removeClass("colors");
    for (var i = 0; i < 50; i++) {
        $(dombatd[RandomNumBoth(0, tdnum - 1)]).addClass("colors");
    }
}

//创建背景td方块
function Buildtd() {
    var w = document.body.clientWidth;
    var h = document.body.clientHeight;
    //宽高比
    var g = parseFloat(parseFloat(w / h).toFixed(2));
    var col = 0;//行
    var row = 0;//列
    if (g > 0) {
        row = parseInt(w / 50);
        col = parseInt(row / g);
    }
    else {
        col = parseInt(h / 50);
        row = parseInt(col / g);
    }

    tdnum = col * row;
    var table = "";
    for (var i = 0; i < col; i++) {
        var html = "<tr>";
        for (var j = 0; j < row; j++) {
            html += "<td class='batd'></td>";
        }
        html += "</tr>";
        table += html;
    }
    $(".Background").append(table);
}



//最小公倍数
function gcd(a,b){
    var minNum = Math.min(a,b),maxNum = Math.max(a,b),i=minNum,vper=0;
    if(a ===0 || b===0){
        return maxNum;
    }

    for(;i<=maxNum;i++){
    vper = minNum * i;
        if(vper % maxNum === 0){
            return vper;
            break;
        }
    }
}

//最大公约数
function getBigFactor(a, b) {
    if (b == 0) {
        return a;
    }
    return getBigFactor(b, a % b)
}