﻿//  data-i18n-html                          .html()
//  data-i18n-text                          .text()
//  data-i18n-val                            .val()
//  data-i18n-title                          .attr("title")
$(document).ready(function () {
    $('[data-i18n-html]').each(function () {
        var message = chrome.i18n.getMessage(this.getAttribute('data-i18n-html'));
        if (message) {
            $(this).html(message);
        }
    });
    $('[data-i18n-text]').each(function () {
        var message = chrome.i18n.getMessage(this.getAttribute('data-i18n-text'));
        if (message) {
            $(this).text(message);
        }
    });
    $('[data-i18n-val]').each(function () {
        var message = chrome.i18n.getMessage(this.getAttribute('data-i18n-val'));
        if (message) {
            $(this).val(message);
        }
    });
    $('[data-i18n-title]').each(function () {
        var message = chrome.i18n.getMessage(this.getAttribute('data-i18n-title'));
        if (message) {
            $(this).prop("title", message);
        }
    });
});