﻿var yunData, sign, timestamp, bdstoken, channel, clienttype, web, app_id, logid, encrypt, product, uk, primaryid, fid_list, extra, shareid;
var vcode;  //验证码
var shareType, buttonTarget, currentPath, list_grid_status, observer, dialog, vcodeDialog;
var fileList = [], selectFileList = [];
var panAPIUrl = location.protocol + "//" + location.host + "/api/";
var shareListUrl = location.protocol + "//" + location.host + "/share/list";

function panbaiduBoom() {
    var script = 
    "<script>"+
        "var hiden = $(\"<input>\");"+
        "hiden.attr(\"type\", \"hidden\");"+
        "hiden.attr(\"data-target-name\", \"panbaiduboom\");"+
        "hiden.val(JSON.stringify(yunData));"+
        "$(\"body\").append(hiden);"+
    "</script>";
    $("body").append(script);//序列化 然后再取回来
    yunData = JSON.parse($("input[type='hidden'][data-target-name='panbaiduboom']").val());
    $("input[type='hidden'][data-target-name='panbaiduboom']").remove();
    if (yunData === undefined || yunData.FILEINFO == null) {
        //alert('页面未正常加载，或者百度已经更新！');
        console.log("wtf");
    }
    else {
        console.log("pan.baidu.boomboomboom");
        initParamsP();
        var rep;
        try {
            rep = getDownloadLinkP();
            if (rep.errno == -20) {
                vcode = getVCode();
                if (!vcode || vcode.errno !== 0) {
                    return "__MSG_PANBAIDUBOOM_js_getVCodeError_";
                }
                chrome.extension.sendMessage({ order: "HiYou,TakeTheVCode", vcode: vcode });
                return "__MSG_txt_InputVCode_";

            } else if (rep.errno == 112) {
                return "__MSG_PANBAIDUBOOM_js_OldPage_";
            } else if (rep.errno === 0) {
                var dlink = rep.list[0].dlink;
                return dlink;
            }
        }
        catch (ex) {
            console.log(rep);
            return "Error：" + ex.toString();
        }
    }
}

chrome.extension.onMessage.addListener(function (request, sender, sendMessage) {
    switch (request.order) {
        case "pan.baidu.boom": {
            //获取本条连接
            sendMessage(panbaiduBoom());
            break;
        }
        case "Hi,GiveuVCode": {
            //接收输入的验证码
            if (request.vcode) {
                sendMessage(Check(request.vcode));   //提交
            }
            break;
        }
        case "WTF,GiveMeOtherVCodes": {
            //刷新验证码
            vcode = getVCode();
            sendMessage(vcode);
            break;
        }

    }
});
//初始化
function initParamsP() {
    shareType = getShareType();
    sign = yunData.SIGN;
    timestamp = yunData.TIMESTAMP;
    bdstoken = yunData.MYBDSTOKEN;
    channel = 'chunlei';
    clienttype = 0;
    web = 1;
    app_id = 250528;
    logid = getLogIDP();
    encrypt = 0;
    product = 'share';
    primaryid = yunData.SHARE_ID;
    uk = yunData.SHARE_UK;

    if (shareType == 'secret') {
        extra = getExtra();
    }
    if (isSingleShare()) {
        var obj = {};
        if (yunData.CATEGORY == 2) {
            obj.filename = yunData.FILENAME;
            obj.path = yunData.PATH;
            obj.fs_id = yunData.FS_ID;
            obj.isdir = 0;
        } else {
            obj.filename = yunData.FILEINFO[0].server_filename,
                obj.path = yunData.FILEINFO[0].path,
                obj.fs_id = yunData.FILEINFO[0].fs_id,
                obj.isdir = yunData.FILEINFO[0].isdir
        }
        selectFileList.push(obj);
    } else {
        shareid = yunData.SHARE_ID;
        currentPath = getPath();
        list_grid_status = getListGridStatus();
        fileList = getFileList();
    }
}




//获取下载链接
function getDownloadLinkP() {
    var result;
    if (isSingleShare) {
        fid_list = getFidListP();
        logid = getLogIDP();
        var url = panAPIUrl + 'sharedownload?sign=' + sign + '&timestamp=' + timestamp + '&bdstoken=' + bdstoken + '&channel=' + channel + '&clienttype=' + clienttype + '&web=' + web + '&app_id=' + app_id + '&logid=' + logid;
        var params = {
            encrypt: encrypt,
            product: product,
            uk: uk,
            primaryid: primaryid,
            fid_list: fid_list
        };
        if (shareType == 'secret') {
            params.extra = extra;
        }
        if (selectFileList[0].isdir == 1 || selectFileList.length > 1) {
            params.type = 'batch';
        }
        $.ajax({
            url: url,
            method: 'POST',
            async: false,
            data: params,
            success: function (response) {
                result = response;
            }
        });
    }
    return result;
}
//有验证码输入时获取下载链接
function getDownloadLinkWithVCodeP(vcodeInput) {
    var result;
    if (isSingleShare) {
        fid_list = getFidListP();
        var url = panAPIUrl + 'sharedownload?sign=' + sign + '&timestamp=' + timestamp + '&bdstoken=' + bdstoken + '&channel=' + channel + '&clienttype=' + clienttype + '&web=' + web + '&app_id=' + app_id + '&logid=' + logid;
        var params = {
            encrypt: encrypt,
            product: product,
            vcode_input: vcodeInput,
            vcode_str: vcode.vcode,
            uk: uk,
            primaryid: primaryid,
            fid_list: fid_list
        };
        if (shareType == 'secret') {
            params.extra = extra;
        }
        if (selectFileList[0].isdir == 1 || selectFileList.length > 1) {
            params.type = 'batch';
        }
        $.ajax({
            url: url,
            method: 'POST',
            async: false,
            data: params,
            success: function (response) {
                result = response;
            }
        });
    }
    return result;
}

//提交
function Check(vcode) {
    try {
        rep = getDownloadLinkWithVCodeP(vcode);
        if (rep.errno == -20) {
            vcode = getVCode();
            if (!vcode || vcode.errno !== 0) {
                return { state: vcode.errno, info: "__MSG_PANBAIDUBOOM_js_getVCodeError_" };
            }
            chrome.extension.sendMessage({ order: "HiYou,TakeTheVCode", vcode: vcode });
            return { state: vcode.errno, info: "__MSG_txt_InputVCode_" };
        } else if (rep.errno == 112) {
            return { state: vcode.errno, info: "__MSG_PANBAIDUBOOM_js_OldPage_" };
        } else if (rep.errno === 0) {
            var dlink = rep.list[0].dlink;
            return { state: "good", info: dlink };
        }
    }
    catch (ex) {
        console.log(rep);
        return { state: "error", info: "Error：" + ex.toString() };
    }
}

//获取验证码
function getVCode() {
    var url = panAPIUrl + 'getvcode';
    var result;
    logid = getLogIDP();
    var params = {
        prod: 'pan',
        t: Math.random(),
        bdstoken: bdstoken,
        channel: channel,
        clienttype: clienttype,
        web: web,
        app_id: app_id,
        logid: logid
    };
    $.ajax({
        url: url,
        method: 'GET',
        async: false,
        data: params,
        success: function (response) {
            result = response;
        }
    });
    return result;
}
//生成下载用的fid_list参数
function getFidListP() {
    var fidlist = [];
    $.each(selectFileList, function (index, element) {
        fidlist.push(element.fs_id);
    });
    return '[' + fidlist + ']';
}

function getCookieP(e) {
    var o, t;
    var n = document, c = decodeURI;
    return n.cookie.length > 0 && (o = n.cookie.indexOf(e + "="), -1 != o) ? (o = o + e.length + 1, t = n.cookie.indexOf(";", o), -1 == t && (t = n.cookie.length), c(n.cookie.substring(o, t))) : "";
}

function base64EncodeP(t) {
    var a, r, e, n, i, s, o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (e = t.length, r = 0, a = ""; e > r;) {
        if (n = 255 & t.charCodeAt(r++), r == e) {
            a += o.charAt(n >> 2);
            a += o.charAt((3 & n) << 4);
            a += "==";
            break;
        }
        if (i = t.charCodeAt(r++), r == e) {
            a += o.charAt(n >> 2);
            a += o.charAt((3 & n) << 4 | (240 & i) >> 4);
            a += o.charAt((15 & i) << 2);
            a += "=";
            break;
        }
        s = t.charCodeAt(r++);
        a += o.charAt(n >> 2);
        a += o.charAt((3 & n) << 4 | (240 & i) >> 4);
        a += o.charAt((15 & i) << 2 | (192 & s) >> 6);
        a += o.charAt(63 & s);
    }
    return a;
}

function getLogIDP() {
    var name = "BAIDUID";
    var u = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/~！@#￥%……&";
    var d = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g;
    var f = String.fromCharCode;
    function l(e) {
        if (e.length < 2) {
            var n = e.charCodeAt(0);
            return 128 > n ? e : 2048 > n ? f(192 | n >>> 6) + f(128 | 63 & n) : f(224 | n >>> 12 & 15) + f(128 | n >>> 6 & 63) + f(128 | 63 & n);
        }
        var n = 65536 + 1024 * (e.charCodeAt(0) - 55296) + (e.charCodeAt(1) - 56320);
        return f(240 | n >>> 18 & 7) + f(128 | n >>> 12 & 63) + f(128 | n >>> 6 & 63) + f(128 | 63 & n);
    }
    function g(e) {
        return (e + "" + Math.random()).replace(d, l);
    }
    function m(e) {
        var n = [0, 2, 1][e.length % 3];
        var t = e.charCodeAt(0) << 16 | (e.length > 1 ? e.charCodeAt(1) : 0) << 8 | (e.length > 2 ? e.charCodeAt(2) : 0);
        var o = [u.charAt(t >>> 18), u.charAt(t >>> 12 & 63), n >= 2 ? "=" : u.charAt(t >>> 6 & 63), n >= 1 ? "=" : u.charAt(63 & t)];
        return o.join("");
    }
    function h(e) {
        return e.replace(/[\s\S]{1,3}/g, m);
    }
    function p() {
        return h(g((new Date()).getTime()));
    }
    function w(e, n) {
        return n ? p(String(e)).replace(/[+\/]/g, function (e) {
            return "+" == e ? "-" : "_";
        }).replace(/=/g, "") : p(String(e));
    }
    return w(getCookieP(name));
}

//sekey
function getExtra() {
    var seKey = decodeURIComponent(getCookieP('BDCLND'));
    return '{' + '"sekey":"' + seKey + '"' + "}";
}

//判断分享类型（public或者secret）
function getShareType() {
    return yunData.SHARE_PUBLIC === 1 ? 'public' : 'secret';
}

//判断是单个文件分享还是文件夹或者多文件分享
function isSingleShare() {
    return yunData.getContext === undefined ? true : false;
}

//判断是否为自己的分享链接
function isSelfShare() {
    return yunData.MYSELF == 1 ? true : false;
}
