﻿//将url相对路径 转换为 绝对路径【这个是自己写的】
function BuildTrueUrl(url) {
    var TrueUrl = "";
    if (url != undefined && url != null && url != "") {
        var img = new Image();
        img.src = url;  // 设置相对路径给Image, 此时会发送出请求
        TrueUrl = img.src;  // 此时相对路径已经变成绝对路径
        img.src = null; // 取消请求
    }
    return TrueUrl;
}

//转换为utf-8
function toUtf8(str) {
    str = str.toString();
    var out, i, len, c;
    out = "";
    len = str.length;
    for (i = 0; i < len; i++) {
        c = str.charCodeAt(i);
        if ((c >= 0x0001) && (c <= 0x007F)) {
            out += str.charAt(i);
        } else if (c > 0x07FF) {
            out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
            out += String.fromCharCode(0x80 | ((c >> 6) & 0x3F));
            out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
        } else {
            out += String.fromCharCode(0xC0 | ((c >> 6) & 0x1F));
            out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
        }
    }
    return out;
}

//移除左右空格
String.prototype.trim = function (ex) {
    if (ex == undefined) {
        return this.replace(/(^\s*)|(\s*$)/g, "");
    }
    else {
        var re = new RegExp("(^" + ex + "*)|(" + ex + "*$)", "gim");
        return this.replace(re, "");
    }
}
String.prototype.ltrim = function (ex) {
    if (ex == undefined) {
        return this.replace(/(^\s*)/g, "");
    }
    else {
        var re = new RegExp("(^" + ex + "*)", "gim");
        return this.replace(re, "");
    }
}
String.prototype.rtrim = function (ex) {
    if (ex == undefined) {
        return this.replace(/(\s*$)/g, "");
    }
    else {
        var re = new RegExp("(" + ex + "*$)", "gim");
        return this.replace(re, "");
    }
}

//添加顶级遮罩
function addMainShadow(text) {
    var dom = "<div class=\"MainShadow\" style=\"position:absolute;z-index:999;top:0;left:0;bottom:0;right:0;background: rgba(0, 0, 0, 0.66);\">" +
        "<table border=0 cellpadding=0 cellspacing=0 style=\"width:100%; height:100%; text-align:center; color:#fff; font-size:50px;\"><tbody><tr><td>" + text + "</td></tr></tbody></table>" +
    "</div>";
    $("body").append(dom);
}
//修改遮罩文字
function setMainShadowMessage(text) {
    $(".MainShadow table tr td").text(text);
}
//移除顶级遮罩
function RemoveMainShadow() {
    $(".MainShadow").remove();
}


var MsgItemIndex = 0;//提示索引

//显示右下角的提示
//type s绿色成功 i黄色提示 e红色错误
function addLeftMsg(type, text) {
    var dom = $(".LeftMsg");
    if (dom == undefined || dom.length == 0) {
        $("body").append("<div class=\"LeftMsg\">");
    }
    if ($(".LeftMsg .MsgItem").length >= 5) //超过4个移除最后一个
    {
        $($(".LeftMsg .MsgItem")[$(".LeftMsg .MsgItem").length-1]).remove();
    }
    var div = $("<div>");
    div.addClass("MsgItem");
    switch (type)
    {
        case "s": {
            div.addClass("Success");
            break;
        }
        case "i": {
            div.addClass("Info");
            break;
        }
        case "e": {
            div.addClass("Error");
            break;
        }
    }
    div.attr("data-id", "MsgItem" + MsgItemIndex);
    div.text(text);
    $(".LeftMsg").prepend(div);

    //$("[data-id='MsgItem" + MsgItemIndex + "']").show(500);
    setTimeout(removeLeftMsg, 10000, MsgItemIndex);

    MsgItemIndex++;
    return 
}
//移除
function removeLeftMsg(index) {
    if (index != undefined) {
        $("[data-id='MsgItem" + index + "']").hide(500);
    }
    else {
        $(".MsgItem").hide(500);
    }
}
//重载setTimeout
var __sto = setTimeout;
window.setTimeout = function (callback, timeout, param) {
    var args = Array.prototype.slice.call(arguments, 2);
    var _cb = function () {
        callback.apply(null, args);
    }
    __sto(_cb, timeout);
}



//通用顶级域     //2018年2月18日07:41:08 增加 特殊顶级域 co ac
var gTLD = ["com", "info", "net", "org", "club", "biz", "name", "pro", "aero", "cat", "coop", "edu", "gov", "int", "jobs", "mil", "mobi", "museum", "travel", "asia", "tel", "post", "xxx", "co", "ac"];
//乱七八糟域
var wtfTLD = ["xin", "top", "xyz", "wang", "shop", "site", "cc", "fun", "online", "red", "link", "so", "ltd", "mobi", "info", "vip", "work", "tv", "kim", "group", "tech", "store", "ren", "ink"];
//国家域名 默认两位算了
var ccTLD = [];
//获取主域名
function getMainHost(url) {
    /*
        先取hostName
        [xxxx][通用顶级域][乱七八糟域][国家域]
    */
    var ret = "";
    url = url.toString().toLowerCase(); //全小写
    url = url.replace("http://", "").replace("https://", "").replace("ftp://", "");
    host = url.split("/")[0];
    littlehost = host.split(".");
    for (var i = littlehost.length - 1; i >= 0; i--) {
        if (i == littlehost.length - 1 && littlehost[i].length == 2) {
            ret = littlehost[i] + "." + ret;
        }
        else if (gTLD.indexOf(littlehost[i]) != -1 || wtfTLD.indexOf(littlehost[i]) != -1) {
            ret = littlehost[i] + "." + ret;
        } else {
            ret = littlehost[i] + "." + ret;
            break;
        }
    }
    return ret;
}