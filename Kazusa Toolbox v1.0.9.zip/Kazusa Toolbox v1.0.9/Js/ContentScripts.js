﻿//接收信息 不管是谁发的
chrome.extension.onMessage.addListener(function (request, sender, sendMessage) {
    switch (request.order) {
        case "CloseLighting": {
            //页面关灯【关灯】
            $("video").addClass("NoCloseLighting");
            var style = "<style id='CloseLightingKazusa'> .NoCloseLighting{background: position: relative;z-index: 99999999;}*:not(.NoCloseLighting){ background: #000 !important; color: #FFFFFF !important; text-shadow: 0 0 10px #000 !important; font-weight: lighter !important; /*font-family: '微软雅黑' !important; */}</style>";
            $("head").append(style);
            break;
        }
        case "OpenLighting": {
            //页面开灯【开灯】
            $("#CloseLightingKazusa").remove();
            break;
        }
        case "GetScreenshot": {
            //var video = document.getElementsByTagName('body');
            //var canvas = document.createElement("canvas");
            //var ctx = canvas.getContext('2d');
            //var width = document.body.clientWidth;
            //var height = document.body.clientHeight;

            //canvas.width = width;
            //canvas.height = height;

            //ctx.drawImage(video, 0, 0, width, height);
            //var base = canvas.toDataURL(); //将截图 生成base64
            ////保存至background
            //chrome.extension.sendMessage({ order: "setScreenshot", Screenshot: base }, function (response) { });

            //截图
            //html2canvas(document.body, {
            //    allowTaint: true,
            //    taintTest: true
            //}).then(function (canvas) {
            //    document.body.appendChild(canvas);
            //    var base = canvas.toDataURL("image/png"); //将截图 生成base64
            //    console.log(base);
            //    //保存至background
            //    chrome.extension.sendMessage({ order: "setScreenshot", Screenshot: base }, function (response) { });
                
            //}).catch(function (e) {
            //    console.log('error', e);
            //});

            html2canvas(document.body).then(function (canvas) {
                var base = canvas.toDataURL("image/png"); //将截图 生成base64
                //console.log(base);
                //保存至background
                chrome.extension.sendMessage({ order: "setScreenshot", Screenshot: base }, function (response) { });
            });
            break;
        }
       
    }
});

