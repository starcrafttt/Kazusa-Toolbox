﻿//一次性消息
function oneTimeMessage() {
    //从content script发送给background：     { order: "mycmd" } 单纯是个标记用的 object
    chrome.extension.sendMessage({ order: "mycmd" }, function (response) { console.log(response); });
    //从background向content script发送消息：
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) { chrome.tabs.sendMessage(tabs[0].id, { order: "mycmd" }, function (response) { console.log(response); }); });
    //接收方代码：
    //chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) 
    chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
        console.log(sender.tab ? "from a content script:" + sender.tab.url : "from the extension");
        if (request.order == "mycmd")
            sendResponse("ok");
    });
}
//长消息
function longMessage() {
    //连接主动方：
    var port = chrome.runtime.connect({ name: "con1" }); port.postMessage({ order: "mycmd" }); port.onMessage.addListener(function (msg) {
        if (msg.recmd == "remycmd") {
            port.postMessage({ order: "mycmd2" });
        }
        else if (msg.recmd == "remycmd2") {
            port.postMessage({ order: "mycmd3" });
        }
    });
    //连接被动方：
    chrome.runtime.onConnect.addListener(function (port) {
        console.assert(port.name == "con1"); port.onMessage.addListener(function (msg) {
            if (msg.order == "mycmd")
                port.postMessage({ recmd: "remycmd" });
            else if (msg.order == "mycmd2")
                port.postMessage({ recmd: "remycmd2" });
            else if (msg.order == "mycmd3")
                port.postMessage({ recmd: "remycmd3" });
        });
    });

}
//下载
//chrome.downloads.download({
//    url:,  //下载的url
//    filename:,  //保存的文件名
//    conflictAction:uniquify,  //重名文件的处理方式 //只能为uniquify(在文件名后面添加带括号的序号，以保证文件名唯一)，overwrite(覆盖)或者 prompt(给出提示，让用户自行决定是对文件进行重命名还是将其覆盖、)
//    saveAs:false,  //是否弹出另存为窗口
//    method:,  //请求方式(post或get)
//    headers:,  //自定义header数组 [object,object,object]  object--> { name:"Referer",value:"urlxxxxxxxxxxxx"}
//    body:,  //post的数据
//}, callback)


$(document).ready(function (e) {
    console.log("%chey,i see u ~", "color:#f60;");
    console.log("%caha~", "color:#f60;");
    console.log("%cXD", "color:#f60;");

    //折叠展示功能【烦死个人了】
    $("[target]").click(function (ex) {
        var target = $(this).attr("target");
        $("[dotarget='" + target + "']").toggle(100);
    });

    //保存本页图片【批量下载图片用】
    $("#DownLoadNowPagePic").click(function () {
        //先清空获取所有图片链接
        chrome.extension.sendMessage({ order: "RemovePagePicArr" }, function () {
            chrome.tabs.getSelected(null, function (tab) {　　// 先获取当前页面的tabID
                //直接通知background 获取当前标签页的 http 请求
                chrome.extension.sendMessage({ order: "setPagePictoSaveArr", tab: tab.id }, function (response) { console.log(response); });
            });
            $('.allDomTempAdd').append('<a href="Function/DownPic.html" id="goto" target="_blank"></a>');
            $('#goto').get(0).click();
            $('#goto').remove();
        });
    });
    //保存当前窗口图片【批量下载图片用】
    $("#DownLoadNowWindowPic").click(function () {
        //先清空获取所有图片链接
        chrome.extension.sendMessage({ order: "RemovePagePicArr" }, function () {
            //获取当前窗口
            chrome.windows.getCurrent(function (win) {
                chrome.tabs.getAllInWindow(win.id, function (tabs) {
                    tabs.forEach(function (tab) {
                        //通知指定标题页 获取所有图片链接 保存到background 
                        chrome.extension.sendMessage({ order: "setPagePictoSaveArr", tab: tab.id }, function (response) { console.log(response); });
                    });
                    $('.allDomTempAdd').append('<a href="Function/DownPic.html" id="goto" target="_blank"></a>');
                    $('#goto').get(0).click();
                    $('#goto').remove();
                })
            });
        });
        
    });
    //保存所有标签图片【批量下载图片用】
    $("#DownLoadALLPagePic").click(function () {
        //先清空获取所有图片链接
        chrome.extension.sendMessage({ order: "RemovePagePicArr" }, function () {
            //获取所有标签栏
            chrome.tabs.query({}, function (tabs) {
                tabs.forEach(function (tab) {
                    //循环通知指定标题页 获取所有图片链接 保存到background 
                    chrome.extension.sendMessage({ order: "setPagePictoSaveArr", tab: tab.id }, function (response) { console.log(response); });
                });
            });
            $('.allDomTempAdd').append('<a href="Function/DownPic.html" id="goto" target="_blank"></a>');
            $('#goto').get(0).click();
            $('#goto').remove();
        });
    });


    //保存本页视频【批量下载视频用】
    $("#DownLoadNowPageVideo").click(function () {
        //先清空获取所有图片链接
        chrome.extension.sendMessage({ order: "RemovePageVideoArr" }, function () {
            chrome.tabs.getSelected(null, function (tab) {　　// 先获取当前页面的tabID
                //通知指定标题页 获取所有图片链接 保存到background 
                chrome.extension.sendMessage({ order: "setPageVideotoSaveArr", tab: tab.id }, function (response) { console.log(response); });
            });
            $('.allDomTempAdd').append('<a href="Function/DownVideo.html" id="goto" target="_blank"></a>');
            $('#goto').get(0).click();
            $('#goto').remove();
        });
    });
    //保存当前窗口视频【批量下载视频用】
    $("#DownLoadNowWindowVideo").click(function () {
        //先清空获取所有图片链接
        chrome.extension.sendMessage({ order: "RemovePageVideoArr" }, function () {
            //获取当前窗口
            chrome.windows.getCurrent(function (win) {
                chrome.tabs.getAllInWindow(win.id, function (tabs) {
                    tabs.forEach(function (tab) {
                        //通知指定标题页 获取所有图片链接 保存到background 
                        chrome.extension.sendMessage({ order: "setPageVideotoSaveArr", tab: tab.id }, function (response) { console.log(response); });
                    });
                    $('.allDomTempAdd').append('<a href="Function/DownVideo.html" id="goto" target="_blank"></a>');
                    $('#goto').get(0).click();
                    $('#goto').remove();
                })
            });
        });

    });
    //保存所有标签视频【批量下载视频用】
    $("#DownLoadALLPageVideo").click(function () {
        //先清空获取所有图片链接
        chrome.extension.sendMessage({ order: "RemovePageVideoArr" }, function () {
            //获取所有标签栏
            chrome.tabs.query({}, function (tabs) {
                tabs.forEach(function (tab) {
                    //循环通知指定标题页 获取所有图片链接 保存到background 
                    chrome.extension.sendMessage({ order: "setPageVideotoSaveArr", tab: tab.id }, function (response) { console.log(response); });
                });
            });
            $('.allDomTempAdd').append('<a href="Function/DownVideo.html" id="goto" target="_blank"></a>');
            $('#goto').get(0).click();
            $('#goto').remove();
        });
    });

    //关灯
    $("#CloseLighting").click(function () {
        chrome.tabs.getSelected(null, function (tab) {　　// 先获取当前页面的tabID
            //通知指定标题页 关灯
            chrome.tabs.sendMessage(tab.id, { order: "CloseLighting" }, function (response) { });
        });
    });
    //开灯
    $("#OpenLighting").click(function () {
        chrome.tabs.getSelected(null, function (tab) {　　// 先获取当前页面的tabID
            //通知指定标题页 关灯
            chrome.tabs.sendMessage(tab.id, { order: "OpenLighting" }, function (response) { });
        });
    });
    //生成二维码
    $("#BuildQRCode").click(function () {
        $(".QR").show(100);
        $('.QRCode').qrcode(toUtf8($(".NowPageUrl").text()));
    });
    //隐藏二维码弹出层遮罩
    $(".QRCodeShadow").click(function () {
        $(".QR").hide(100);
    });

    //截屏
    $("#BuildScreenshot").click(function () {
        chrome.tabs.getSelected(null, function (tab) {　　// 先获取当前页面的tabID
            //通知指定标题页 获取所有图片链接 保存到background 
            chrome.tabs.sendMessage(tab.id, { order: "GetScreenshot" }, function (response) { });
        });
    });    
    //测试桌面提示
    $("#QuickFunction_2").click(function () {
        //chrome.extension.sendMessage({ order: "showNotiofication" }, function (e) { console.log(e); });
        var options = {
            dir: "ltr",  //控制方向，据说目前浏览器还不支持
            lang: "utf-8",
            icon: "../Img/snowflake.png",
            body: "__MSG_POPUP_js_Notification_Body_"
        };
        var n = new Notification("__MSG_POPUP_js_Notification_Title_", options);
    });

    //显示书签
    $(".ShowBooksMark").click(function () {
        if ($(this).attr("data-state") == "no") {
            dumpBookmarks();    //加载书签
        }
    });

    //百度网盘下载
    $("#PanBaiduBoom_1").click(function () {
        $(".PanVCode").hide();  //先隐藏验证码
        chrome.tabs.getSelected(null, function (tab) {　　// 先获取当前页面的tabID
            chrome.tabs.sendMessage(tab.id, { order: "pan.baidu.boom" }, function (response) {
                $("#txtDownLoadUrl").val(response);
                $(".PanBaidu").show(100);
            });
        });
    });
    //隐藏百度网盘下载弹出层遮罩
    $(".DownLoadUrlShadow").click(function () {
        $(".PanBaidu").hide(100);
    });
    //更换验证码
    $(".imgPanVCode").click(function () {
        chrome.tabs.getSelected(null, function (tab) {　　// 先获取当前页面的tabID
            chrome.tabs.sendMessage(tab.id, { order: "WTF,GiveMeOtherVCodes" }, function (vcode) {
                $(".imgPanVCode").attr("src", vcode.img);
            });
        });
    });
    //确认百度网盘验证码
    $(".btnPanVCode").click(function () {
        var VCode = $(".txtPanVCode").val();
        chrome.tabs.getSelected(null, function (tab) {　　// 先获取当前页面的tabID
            chrome.tabs.sendMessage(tab.id, { order: "Hi,GiveuVCode", vcode: VCode }, function (vcode) {
                if (vcode.state === "good") {
                    $(".PanVCode").hide(100);
                    $("#txtDownLoadUrl").val(vcode.info);
                }
            });
        });
    });
    //取消验证 - 隐藏下载
    $(".btnPanVCode_exit").click(function () {
        $(".PanBaidu").hide(100);
        $(".PanVCode").hide(100);
    });
});

//系统信息
//chrome.system.cpu.getInfo(function (info) { console.log(info); });
//chrome.system.memory.getInfo(function (info) { console.log(info); });
//chrome.system.storage.getInfo(function (info) { console.log(info); });

////当前窗口下的标签栏
//chrome.windows.getCurrent(function (win) {
//    chrome.tabs.getAllInWindow(win.id, function (tabs) {
//        tabs.forEach(function (tab) {
//            $('.tableIDs').append("<br>当前窗口下的标签栏ID：" + tab.id);
//        });
//    });
//});

////获取所有标签栏
//chrome.tabs.query({}, function (tabs) {
//    tabs.forEach(function (tab) {
//        //复制标签栏
//        //chrome.tabs.duplicate(tab.id, function (copy) {
//        //    console.log(copy.title);  // copy 是复制出来的 tab
//        //})
//        $('.tableIDs').append("<br>所有标签栏的ID：" + tab.id);
//    });
//});

//当前标签栏
chrome.tabs.getSelected(null, function (tab) {　　// 先获取当前页面的tabID

    chrome.tabs.get(tab.id, function (tabs) {
        $(".NowPageTitle").text(tabs.title);
        $(".NowPageUrl").text(tabs.url);
    });

    //$('.NowTableID').text("当前标签栏ID：" + tab.id);

    //获取当前页title url由 ContentScripts.js处理  消息直接发送到指定的 tabs
    //chrome.tabs.sendMessage(tab.id, { order: "GetPageInfo" }, function (response) {
    //    //"当前页面标题："
    //    $(".NowPageTitle").text(response.title);
    //    //"当前页面Url："
    //    $(".NowPageUrl").text(response.url);
    //});

    //【不许删除，谁删谁是王八蛋】
    ////获取当前title url由background 处理 
    //chrome.extension.sendMessage({ order: "getTitleArr", tabID: tab.id }, function (response) {
    //    if (response.title) {
    //        $('body').append("<br>当前页的title - 来自background：" + response.title);
    //        $('body').append("<br>当前页的url - 来自background：" + response.url);
    //    }
    //});
    
});



//总入口【获取书签】
function dumpBookmarks(query) {

    var bookmarkTreeNodes = chrome.bookmarks.getTree(function (bookmarkTreeNodes) {
        var dom = dumpTreeNodes(bookmarkTreeNodes, query);
        //去掉无用外层<ul><div>
        while (dom.children().length == 1) {
            dom = $(dom.html());
        }
        $(dom.find("ul")).hide();   //除了基础的ul 全部隐藏
        $(".bookmarks").append(dom);
        $(".ShowBooksMark").attr("data-state", "yes");

        //循环绑定样式
        var dom = $(".bookmarks a");
        for (var i = 0, max = dom.length; i < max; i++) {
            if ($(dom[i]).next("ul").length != 0) {
                $(dom[i]).addClass("Menu");
                $(dom[i]).prepend("<i class='icoFont'>&#xf07c;</i>");
            }
            else {
                if ($(dom[i]).attr("href") == undefined || $(dom[i]).attr("href") == "") {
                    $(dom[i]).text(chrome.i18n.getMessage("POPUP_js_BooksMarks_no") + $(dom[i]).text());
                    $(dom[i]).addClass("Menu");
                    $(dom[i]).prepend("<i class='icoFont'>&#xf07c;</i>")
                }
            }
        }

        $(".Menu").click(function () {
            $(this).next("ul").toggle(50);
        });

    });

}
//获取树  父级【获取书签】
function dumpTreeNodes(bookmarkNodes, query) {
    var list = $('<ul>');
    var i;
    for (i = 0; i < bookmarkNodes.length; i++) {
        list.append(dumpNode(bookmarkNodes[i], query));
    }
    return list;
}
//子级【获取书签】
function dumpNode(bookmarkNode, query) {

    if (bookmarkNode.title) {
        if (query && !bookmarkNode.children) {
            if (String(bookmarkNode.title).indexOf(query) == -1) {
                return $('<span></span>');
            }
        }
        var anchor = $('<a>');
        anchor.attr('href', bookmarkNode.url);
        anchor.attr('target', "_block");
        anchor.text(bookmarkNode.title);
        //anchor.click(function () {
        //    chrome.tabs.create({ url: bookmarkNode.url });
        //});
    }


    var li = $(bookmarkNode.title ? '<li>' : '<div>').append(anchor);
    if (bookmarkNode.children && bookmarkNode.children.length > 0) {
        li.append(dumpTreeNodes(bookmarkNode.children, query));
    }
    return li;
}



//通知background 读取书签
//chrome.extension.sendMessage({ order: "getBookmarks" });

//接收通知
chrome.extension.onMessage.addListener(function (request, sender, sendMessage) {
    switch (request.order) {
        case "ScreenshotSaveOver": {
            //截图完成 打开新页面
            $('.allDomTempAdd').append('<a href="Function/Screenshot.html" id="goto" target="_blank"></a>');
            $('#goto').get(0).click();
            $('#goto').remove();
            break;
        }
        case "HiYou,TakeTheVCode": {
            //百度云验证码
            if (request.vcode) {
                $(".imgPanVCode").attr("src", request.vcode.img);
                $(".PanVCode").show(100);
            }
            break;
        }
    }
});

