﻿arr_PicArr = new Array();       //[{Object},{referer: 当前资源父页面 , nowUrl:当前资源url}]      用作传递
arr_VideoArr = new Array();   //[{Object},{referer: 当前资源父页面 , nowUrl:当前资源url，title:假冒伪劣的文件名 ,rang:数据尺寸单位，length:长度}]      用作传递

var strScreenshot = "";    //截屏信息base64

//字符串索引的含义其实是 对对象添加的一个属性
var global_Response_OtherRes = new Object();     //标签http请求 其余资源  "tableID" ：{Info : { Object } ,webResponse :  array[ 连接object，连接object ]}
var global_Response_PicRes = new Object();         //标签http请求 图片资源  "tableID" ：{Info : { Object } ,webResponse :  array[ 连接object，连接object ]}
var global_Response_VideoRes = new Object();     //标签http请求 视频资源  "tableID" ：{Info : { Object } ,webResponse :  array[ 连接object，连接object ]}
var global_tabsIDs = ""; //*ID**ID**ID**ID*

var IWantToPlayThisVideo = new Array();                       //需要临时伪造的url  url，url，url
var IWantToPlayThisVideoReferer = new Object();         //临时伪造referer   url:referer

var picContentType =
    ["image","img","image/gif", "image/x-icon", "image/jpeg", "image/png",
        "application/x-bmp", "application/x-ps","application/x-img", "application/x-ico",
        "application/x-jpg", "application/x-png", "Model/vnd.dwf", "webp"];
var picSuffix = ['.gif', '.icon', '.ico', '.jpg', '.jpeg', '.png', '.webp', 'data:image'];
var videoContentType =
[   "video", "media", "application/ogg", "video/mpeg", "video/mpeg4", "video/mpg", "video/x-mpeg",
    "application/x-shockwave-flash", "application/flash", "video/x-ms-asf", "video/avi", "video/x-ivf",
    "video/x-mpg", "video/x-mpeg", "video/mpg", "video/flv", "application/flv", "video/x-flv", "fetch"];/*fetch B站分段flv*/
var videoSuffix =
[   '.ogg', '.mpeg4', '.mpg', '.swf',
    '.avi', '.flv', '.mp4', '.mov',
    '.wmv', '.3gp', '.mkv', '.f4v',
    '.rmvb', 'data:video'];
var musicContentType = ["audio/rn-mpeg", "audio/mp1", "audio/mp2", "audio/mp3", "audio/wav"];



chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
    //alert(sender.tab ? "from a content script:" + sender.tab.url + "\n" + "TableID:" + sender.tab.id: "from the extension");
    switch (request.order) {
        case "setPagePictoSaveArr": {
            //保存页面图片【批量下载图片用】
            if (request.tab) {
                console.time("tabs:" + tableID + " GetVideo -> Done");
                var tableID = (request.tab).toString();
                var tableInfos = global_Response_PicRes[tableID].Info;                 //获取基本信息
                var webResponse = global_Response_PicRes[tableID].webResponse;    //获取http请求
                var refererUrl = tableInfos.url;                                                        //先从基础信息中提取 refererUrl
                for (var i = 0, max = webResponse.length; i < max; i++) {
                    arr_PicArr.push({ referer: refererUrl, nowUrl: webResponse[i].url })
                }
                console.timeEnd("tabs:" + tableID + " GetVideo -> Done");
            }
            else {
                console.log("tabs:" + tableID + " GetVideo -> Error no tableID");
            }
            break;
        }
        case "getPagePictoSaveArr": {
            //返回页面图片【批量下载图片用】
            sendResponse({ arr: arr_PicArr });  
            break;
        }
        case "RemovePagePicArr": {
            //清空图片数组【批量下载图片用】
            arr_PicArr = new Array();
            break;
        }
        case "setPageVideotoSaveArr": {
            //保存页面视频【批量下载视频用】
            if (request.tab) {
                console.time("tabs:" + tableID + " GetVideo -> Done");
                var tableID = (request.tab).toString();
                var tableInfos = global_Response_VideoRes[tableID].Info;                    //获取基本信息
                var webResponse = global_Response_VideoRes[tableID].webResponse;    //获取http请求
                var refererUrl = tableInfos.url;                                                            //先从基础信息中提取 refererUrl
                var refererUrlHost = getMainHost(refererUrl);
                for (var i = 0, max = webResponse.length; i < max; i++) {
                    var title = "";     //假冒伪劣的文件名          如果是当前页面的主域名下的 就返回当前页面的title   否则直接保存主域名
                    var nowUrlHost = getMainHost(webResponse[i].url);
                    if (nowUrlHost == refererUrlHost) {
                        title = tableInfos.title;
                    }
                    else {
                        title = nowUrlHost.split(".")[0];
                    }
                    arr_VideoArr.push({ referer: refererUrl, nowUrl: webResponse[i].url, title: title, rang: webResponse[i]["h_Accept-Ranges"], length: webResponse[i]["h_Content-Length"] });
                }
                console.timeEnd("tabs:" + tableID + " GetVideo -> Done");
            }
            else {
                console.log("tabs:" + tableID + " GetVideo -> Error no tableID");
            }
            break;
        }
        case "getPageVideotoSaveArr": {
            //返回页面视频【批量下载视频用】
            sendResponse({ arr: arr_VideoArr });
            break;
        }
        case "RemovePageVideoArr": {
            //清空视频数组【批量下载视频用】
            arr_VideoArr = new Array();
            break;
        }       /*清空视频数组【批量下载视频用】*/
        case "getScreenshot": {
            //获取截屏信息base64
            sendResponse({ Screenshot: strScreenshot });
            break;
        }                   /*获取截屏*/
        case "setScreenshot": {
            //保存截屏信息base64
            strScreenshot = request.Screenshot;
            //保存成功直接发给 popup
            chrome.extension.sendMessage({ order: "ScreenshotSaveOver", Screenshot: strScreenshot }, function (response) { });
            break;
        }
        case "I want to play this video": {
            //添加临时url 进行Referer 仿造
            if (request.Resquest) {
                IWantToPlayThisVideo.push(request.Resquest.url.toString());
                IWantToPlayThisVideoReferer[request.Resquest.url.toString()] = request.Resquest.referer.toString();
                break;
            }
        }
        case "I wantnot to play this video": {
            //移除临时url Referer仿造
            if (request.url) {
                IWantToPlayThisVideo.splice($.inArray(request.url.toString(), IWantToPlayThisVideo), 1);
                delete IWantToPlayThisVideoReferer[request.url.toString()]
            }
            break;
        }
    }
});

//内存清理  清除不必要的 webResponse 和 tabsObject
function ClearMemory() {
    for (var tableID in global_Response_OtherRes) {
        if (global_tabsIDs.indexOf("*" + tableID + "*") == -1) {
            delete global_Response_OtherRes[tableID];    //使用delete 删除当前项
        }
    } 
}
setInterval(ClearMemory, 1000 * 60 * 5);


//https://chajian.baidu.com/developer/extensions/webRequest.html

//拦截页面请求 获取请求  details 实际请求的object
chrome.webRequest.onBeforeRequest.addListener(function (details) {
    //之前写错了 全部转移至 response 
    //console.log(details.url);


},
{ urls: ["<all_urls>"] },["blocking"]);

//改造请求头部Headers  仿造referer 下载使用
chrome.webRequest.onBeforeSendHeaders.addListener(function (details) {
    var refererIndex = -1;
    var hasDownLoadType = false;
    var hasDownLoadReferer = "";

    if (IWantToPlayThisVideo.indexOf(details.url.toString()) != -1) {
        //临时伪装
        for (var i = 0; i < details.requestHeaders.length; i++) {
            if (details.requestHeaders[i].name === 'referer' || details.requestHeaders[i].name === 'Referer') {
                refererIndex = i;
            }
        }
        if (refererIndex == -1) {
            details.requestHeaders.push({ name: "Referer", value: IWantToPlayThisVideoReferer[details.url.toString()] });
        }
        else {
            details.requestHeaders[refererIndex] = IWantToPlayThisVideoReferer[details.url.toString()];
        }
    }
    else {
        //日常伪装
        //遍历requestHeaders 获取
        for (var i = 0; i < details.requestHeaders.length; i++) {
            if (details.requestHeaders[i].name === 'DownLoadType' && details.requestHeaders[i].value === 'KazusaToolDownLoad') {
                hasDownLoadType = true;
                details.requestHeaders.splice(i, 1);    //移除头
                i--;
            } else if (details.requestHeaders[i].name === 'referer' || details.requestHeaders[i].name === 'Referer') {
                refererIndex = i;
            }
            else if (details.requestHeaders[i].name === 'DownLoadTypeReferer') {
                hasDownLoadReferer = details.requestHeaders[i].value;
                details.requestHeaders.splice(i, 1);    //移除头
                i--;
            }
        }
        if (hasDownLoadType) {
            if (refererIndex == -1) {
                details.requestHeaders.push({ name: "Referer", value: hasDownLoadReferer });
            }
            else {
                details.requestHeaders[refererIndex] = hasDownLoadReferer;
            }
        }
    }
    return { requestHeaders: details.requestHeaders };
},
{ urls: ["<all_urls>"] },
["blocking", "requestHeaders"]);

var onResponseStarted = 0;
//获取服务器回来的资源    Content-Type ！= details.type
chrome.webRequest.onResponseStarted.addListener(function (details) {
    onResponseStarted++;
    //console.log("%cA new Response:", "color:#f60;");
    //console.time('解析时间为');
    //console.log(details.url);

    var tableID = (details.tabId).toString();
    var nowdetailsUrl = details.url;
    var nowdetailsType = "";

    //循环 
    for (var i = 0; i < details.responseHeaders.length; i++) {
        details["h_"+details.responseHeaders[i].name.toString()] = details.responseHeaders[i].value;
    }
    delete details.responseHeaders;
    nowdetailsType = details["h_Content-Type"];
    //console.log(details);

    //更新 保存标签http请求的 Object  并返回资源类型
    var ResType = UpLoadResponseObject(tableID, nowdetailsType, nowdetailsUrl);    //-1错误 0其他  1图片  2视频  3.....没有了 待定

    //分类保存
    switch (ResType.toString()) {
        case "0": {
            var flagOtherRes = true;
            var webResponse = global_Response_OtherRes[tableID].webResponse;
            for (var i = 0, max = webResponse.length; i < max; i++) {
                if (webResponse[i].url == nowdetailsUrl && webResponse[i].type == nowdetailsType) {
                    flagOtherRes = false;
                    break;
                }
            }
            if (flagOtherRes) {
                global_Response_OtherRes[tableID].webResponse.push(details);
            }
            break;
        }
        case "1": {
            var flagOtherRes = true;
            var webResponse = global_Response_PicRes[tableID].webResponse;
            for (var i = 0, max = webResponse.length; i < max; i++) {
                if (webResponse[i].url == nowdetailsUrl && webResponse[i].type == nowdetailsType) {
                    flagOtherRes = false;
                    break;
                }
            }
            if (flagOtherRes) {
                global_Response_PicRes[tableID].webResponse.push(details);
            }
            break;
        }
        case "2": {
            var flagOtherRes = true;
            var webResponse = global_Response_VideoRes[tableID].webResponse;
            for (var i = 0, max = webResponse.length; i < max; i++) {
                if (webResponse[i].url == nowdetailsUrl && webResponse[i].type == nowdetailsType) {
                    flagOtherRes = false;
                    break;
                }
            }
            if (flagOtherRes) {
                global_Response_VideoRes[tableID].webResponse.push(details);
            }
            break;
        }
    }

    //console.timeEnd('解析时间为');
    

},
{ urls: ["<all_urls>"] },
["responseHeaders"]);

/*
onBeforeRequest
            ↓
onBeforeSendHeaders
            ↓
onSendHeaders
            ↓
onHeadersReceived
            ↓
onAuthRequired
            ↓
onBeforeRedirect
            ↓
onResponseStarted
            ↓
onCompleted / onErrorOccurred
*/


//更新 保存标签http请求的 Object  并  返回资源类型  【Response】
//tableID  tableID
//restype  资源类型 (Response)
//resurl    资源链接
//return -1错误  0其他  1图片  2视频  3.....没有了 待定
function UpLoadResponseObject(tableID, restype, resurl) {
    if (tableID != undefined && tableID != -1) {
        //#region   其余资源
        if (global_Response_OtherRes[tableID] == undefined) {
            global_Response_OtherRes[tableID] = new Object();                         //初始对象
        }
        if (global_Response_OtherRes[tableID].Info == undefined) {
            global_Response_OtherRes[tableID].Info = new Object();                //初始对象
            chrome.tabs.get(parseInt(tableID), function (tabs) {
                global_Response_OtherRes[tableID].Info = tabs;
            });
        }
        if (global_Response_OtherRes[tableID].webResponse == undefined) {
            global_Response_OtherRes[tableID].webResponse = new Array();    //初始对象 webResponse
        }
        //#endregion

        //#region   图片资源
        if (global_Response_PicRes[tableID] == undefined) {
            global_Response_PicRes[tableID] = new Object();                         //初始对象
        }
        if (global_Response_PicRes[tableID].Info == undefined) {
            global_Response_PicRes[tableID].Info = new Object();                //初始对象
            chrome.tabs.get(parseInt(tableID), function (tabs) {
                global_Response_PicRes[tableID].Info = tabs;
            });
        }
        if (global_Response_PicRes[tableID].webResponse == undefined) {
            global_Response_PicRes[tableID].webResponse = new Array();    //初始对象 webResponse
        }
        //#endregion

        //#region   视频资源
        if (global_Response_VideoRes[tableID] == undefined) {
            global_Response_VideoRes[tableID] = new Object();                         //初始对象
        }
        if (global_Response_VideoRes[tableID].Info == undefined) {
            global_Response_VideoRes[tableID].Info = new Object();                //初始对象
            chrome.tabs.get(parseInt(tableID), function (tabs) {
                global_Response_VideoRes[tableID].Info = tabs;
            });
        }
        if (global_Response_VideoRes[tableID].webResponse == undefined) {
            global_Response_VideoRes[tableID].webResponse = new Array();    //初始对象 webResponse
        }
        //#endregion

        try {
            //先判断 Content-Type
            if (picContentType.indexOf(restype) != -1) {
                return 1;
            }
            else if (videoContentType.indexOf(restype) != -1) {
                return 2;
            }

            for (var i = 0, max = picSuffix.length; i < max; i++) {
                if (resurl.indexOf(picSuffix[i]) != -1) {
                    return 1;
                }
            }
            for (var i = 0, max = videoSuffix.length; i < max; i++) {
                if (resurl.indexOf(videoSuffix[i]) != -1) {
                    return 2;
                }
            }

            return 0;
        }
        catch (ex) {
            return -1;
        }
    }
    else {
        return -1;
    }
}


//标签关闭事件 移除整个 global_Response_OtherRes[tableID]
chrome.tabs.onRemoved.addListener(function (tabID) {
    if (global_Response_OtherRes[tabID.toString()] != undefined) {
        delete global_Response_OtherRes[tabID.toString()];    
    }
    if (global_Response_PicRes[tabID.toString()] != undefined) {
        delete global_Response_PicRes[tabID.toString()];
    }
    if (global_Response_VideoRes[tabID.toString()] != undefined) {
        delete global_Response_VideoRes[tabID.toString()];
    }
    global_tabsIDs = global_tabsIDs.replace("*" + tabID + "*", ""); //从队列里移除
});

//标签新建事件   创建一个 global_Response_OtherRes[tableID] 并对.Info赋值
chrome.tabs.onCreated.addListener(function (tab) {
    var tabID = tab.id.toString();
    global_tabsIDs = global_tabsIDs.replace("*" + tabID + "*", "") + "*" + tabID + "*"; //加入至队列
    //#region   其余资源
    if (global_Response_OtherRes[tabID] == undefined) {
        global_Response_OtherRes[tableID] = new Object();                         //初始对象
    }
    if (global_Response_OtherRes[tabID].Info == undefined) {
        global_Response_OtherRes[tableID].Info = new Object();                //初始对象
    }
    if (global_Response_OtherRes[tabID].webResponse == undefined) {
        global_Response_OtherRes[tableID].webResponse = new Array();    //初始对象 webResponse
    }
    //#endregion

    //#region   图片资源
    if (global_Response_PicRes[tabID] == undefined) {
        global_Response_PicRes[tableID] = new Object();                         //初始对象
    }
    if (global_Response_PicRes[tabID].Info == undefined) {
        global_Response_PicRes[tableID].Info = new Object();                //初始对象
    }
    if (global_Response_PicRes[tabID].webResponse == undefined) {
        global_Response_PicRes[tableID].webResponse = new Array();    //初始对象 webResponse
    }
    //#endregion

    //#region   视频资源
    if (global_Response_VideoRes[tabID] == undefined) {
        global_Response_VideoRes[tableID] = new Object();                         //初始对象
    }
    if (global_Response_VideoRes[tabID].Info == undefined) {
        global_Response_VideoRes[tableID].Info = new Object();                //初始对象
    }
    if (global_Response_VideoRes[tabID].webResponse == undefined) {
        global_Response_VideoRes[tableID].webResponse = new Array();    //初始对象 webResponse
    }
    //#endregion
    global_Response_OtherRes[tabID.toString()].Info = tab;
    global_Response_PicRes[tabID.toString()].Info = tab;
    global_Response_VideoRes[tabID.toString()].Info = tab;
});

//标签更新
chrome.tabs.onUpdated.addListener(function (tabID, changeInfo, tab) {
    tableID = tabID.toString();
    global_tabsIDs = global_tabsIDs.replace("*" + tableID + "*", "") + "*" + tableID + "*"; //加入至队列
    //#region   其余资源
    if (global_Response_OtherRes[tableID] == undefined) {
        global_Response_OtherRes[tableID] = new Object();                         //初始对象
    }
    if (global_Response_OtherRes[tableID].Info == undefined) {
        global_Response_OtherRes[tableID].Info = new Object();                //初始对象
    }
    if (global_Response_OtherRes[tableID].webResponse == undefined) {
        global_Response_OtherRes[tableID].webResponse = new Array();    //初始对象 webResponse
    }
    //#endregion

    //#region   图片资源
    if (global_Response_PicRes[tableID] == undefined) {
        global_Response_PicRes[tableID] = new Object();                         //初始对象
    }
    if (global_Response_PicRes[tableID].Info == undefined) {
        global_Response_PicRes[tableID].Info = new Object();                //初始对象
    }
    if (global_Response_PicRes[tableID].webResponse == undefined) {
        global_Response_PicRes[tableID].webResponse = new Array();    //初始对象 webResponse
    }
    //#endregion

    //#region   视频资源
    if (global_Response_VideoRes[tableID] == undefined) {
        global_Response_VideoRes[tableID] = new Object();                         //初始对象
    }
    if (global_Response_VideoRes[tableID].Info == undefined) {
        global_Response_VideoRes[tableID].Info = new Object();                //初始对象
    }
    if (global_Response_VideoRes[tableID].webResponse == undefined) {
        global_Response_VideoRes[tableID].webResponse = new Array();    //初始对象 webResponse
    }
    //#endregion
    global_Response_OtherRes[tableID].Info = tab;
    global_Response_PicRes[tableID].Info = tab;
    global_Response_VideoRes[tableID].Info = tab;

    if (changeInfo.status == "loading")
    {
        global_Response_OtherRes[tableID].webResponse = new Array();    //刷新后重置http请求
        global_Response_PicRes[tableID].webResponse = new Array();        //刷新后重置http请求
        global_Response_VideoRes[tableID].webResponse = new Array();    //刷新后重置http请求
    }

})

////标签激活
//chrome.tabs.onActivated.addListener(function (tab) {
//})