﻿//发送信息 获取background 中的 所有图片链接
chrome.extension.sendMessage({ order: "getPageVideotoSaveArr" }, function (response) {
    if (response.arr) {
        var array = response.arr;
        var html =
                        "<li class=\"VideoList\" tag=\"{index}\"> " +
                        "    <div class=\"remove\" title=\"" + chrome.i18n.getMessage("txt_CancelSelect") + "\" tag=\"{index}\">X</div> " +
                        "    <div class=\"info\"> " +
                        "        <div class=\"title ellipsis\" title=\"{title}\">{title}</div> " +
                        "        <input class=\"url ellipsis\" value='{littleurl}' readonly /> " +
                        "    </div> " +
                        "    <div class=\"size ellipsis\" title=\"{size}\">{size}</div> " +
                        "    <div class=\"play_Default ellipsis\" title=\"" + chrome.i18n.getMessage("txt_Preview") + " \" data-url=\"{url}\" data-referer=\"{referer}\"> " + chrome.i18n.getMessage("txt_Preview") + " </div> " +
                        "    <div class=\"play ellipsis\" title=\"" + chrome.i18n.getMessage("txt_Preview_Camouflage") + "\" data-url=\"{url}\" data-referer=\"{referer}\">" + chrome.i18n.getMessage("txt_Preview_Camouflage") + "</div> " +
                        "    <div class=\"DownVideo_Default\" data-url=\"{url}\" data-downloadname=\"{downloadname}\" tag=\"{index}\" tag=\"{index}\" title=\"" + chrome.i18n.getMessage("txt_DownLoad_Default") + "\">" + chrome.i18n.getMessage("txt_DownLoad_Default") + "</div>" +
                        "    <div class=\"DownVideo\" data-url=\"{url}\" data-referer=\"{referer}\" data-downloadname=\"{downloadname}\" tag=\"{index}\" tag=\"{index}\" title=\"" + chrome.i18n.getMessage("txt_DownLoad_Camouflage") + "\">" + chrome.i18n.getMessage("txt_DownLoad_Camouflage") + "</div>" +
                        "    <div class=\"clear\"></div> " +
                        "</li> ";
        
        $(".allNum").text(array.length);    //总数
        var temphtml = "";
        //先生成体积
        for (var i = 0, max = array.length; i < max; i++) {
            if (array[i] != null && array[i] != undefined && array[i] != "") {
                var nowUrl = array[i].nowUrl;   //真实url
                var referer = array[i].referer;   //refererUrl  //这个页面的url
                var littleurl = nowUrl.split("?")[0];   //去掉参数的短链接
                var size = array[i].length;   //长度
                var rang = (array[i].rang == undefined ? "" : array[i].rang).toString().toLowerCase();//长度的单位
                var title = array[i].title;   //文件名
                var downloadname = title + "." + littleurl.split(".")[littleurl.split(".").length - 1];     //title+.+后缀名


                if (size != undefined) {
                    switch (rang)
                    {
                        case "bytes": { size = (parseInt(size) / 1024 / 1024).toFixed(2) + "MB"; break; }
                        default: { size = (parseInt(size) / 1024 / 1024).toFixed(2) + "MB"; break; }
                    }
                }
                temphtml = html.replace(/{index}/g, i).replace(/{url}/g, nowUrl).replace(/{referer}/g, referer).replace(/{size}/g, size).replace(/{title}/g, title).replace(/{littleurl}/g, littleurl).replace(/{downloadname}/g, downloadname) + temphtml;
            }
        }
        $(".Videos").append(temphtml);
        //单独点伪造下载
        $(".DownVideo").click(function () {

            var downloadUrl = $(this).attr("data-url");
            var downloadName = $(this).attr("data-downloadname");
            var downloadReferer = $(this).attr("data-referer");
            var Folder = downMainFolder + downloadName;
            //var Folder = downloadName;
            //下载
            console.log(downloadName);
            chrome.downloads.download({
                url: downloadUrl,  //下载的url
                filename: Folder,  //保存的文件名
                conflictAction: "uniquify",  //重名文件的处理方式 //只能为uniquify(在文件名后面添加带括号的序号，以保证文件名唯一)，overwrite(覆盖)或者 prompt(给出提示，让用户自行决定是对文件进行重命名还是将其覆盖、)
                saveAs: false,  //是否弹出另存为窗口
                headers: [{ name: "DownLoadType", value: "KazusaToolDownLoad" }, { name: "DownLoadTypeReferer", value: downloadReferer }],  //自定义header数组 [object,object,object]  object--> { name:"Referer",value:"urlxxxxxxxxxxxx"}
            }, function (downloadId) {
                if (downloadId != undefined) {
                    addLeftMsg("s",chrome.i18n.getMessage("txt_CreateDownLoad_Success") + downloadId);
                }
                else {
                    addLeftMsg("e", chrome.i18n.getMessage("txt_CreateDownLoad_Error"));
                }
            });

        });
        //单独点普通下载
        $(".DownVideo_Default").click(function () {

            var downloadUrl = $(this).attr("data-url");
            var downloadName = $(this).attr("data-downloadname");
            var downloadReferer = $(this).attr("data-referer");
            var Folder = downMainFolder + downloadName;
            //var Folder = downloadName;
            //下载
            console.log(downloadName);
            chrome.downloads.download({
                url: downloadUrl,  //下载的url
                filename: Folder,  //保存的文件名
                conflictAction: "uniquify",  //重名文件的处理方式 //只能为uniquify(在文件名后面添加带括号的序号，以保证文件名唯一)，overwrite(覆盖)或者 prompt(给出提示，让用户自行决定是对文件进行重命名还是将其覆盖、)
                saveAs: false,  //是否弹出另存为窗口
            }, function (downloadId) {
                if (downloadId != undefined) {
                    addLeftMsg("s", chrome.i18n.getMessage("txt_CreateDownLoad_Success") + downloadId);
                }
                else {
                    addLeftMsg("e",chrome.i18n.getMessage("txt_CreateDownLoad_Error"));
                }
            });

        });
        //----css 延迟
        var dom = $(".VideoList");
        var delay = 0.05;
        for (var i = 0, max = dom.length; i < max; i++) {
            $($(dom)[i]).css("animation-delay", delay + "s");
            delay += 0.01;
        }
        //---css 延迟

        //点击添加叉号遮罩
        $(".remove").click(function () {
            $(this).parents(".VideoList").toggleClass("VideoDisabled");
            getNowNum();
        });
        //伪装预览
        $(".play").click(function () {
            var playUrl = $(this).attr("data-url");
            var playReferer = $(this).attr("data-referer");
            //showPreView(playUrl, playReferer);    //这个是XMLHttpRequest
            PlayPreView(playUrl, playReferer);
        });
        //普通预览
        $(".play_Default").click(function () {
            var playUrl = $(this).attr("data-url");
            PlayPreView(playUrl);
        });
        //关闭预览
        $(".PreViewShadow").click(function () {
            ClosePreView();
        });

        $(".url").dblclick(function () {
            var e = $(this);
            e.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            addLeftMsg("s", chrome.i18n.getMessage("txt_CopyLink_Success"));
        });
        getNowNum();//统计总数

    }
});

//计算 $(".Pics .PicBlock").not(".PicNone");的量
function getNowNum() {
    var dom = $(".Videos .VideoList").not(".VideoDisabled");
    $(".nowNum").text(dom.length);
}


var nowDate = new Date();
var downMainFolder = "";
$(document).ready(function (e) {
    downMainFolder = chrome.i18n.getMessage("manifestName") + " VideoDownLoad [" + nowDate.getFullYear() + "-" + (parseInt(nowDate.getMonth()) + 1) + "-" + nowDate.getDate() + " " + nowDate.getHours() + "_" + nowDate.getMinutes() + "_" + nowDate.getSeconds() + "]/";
    //全部下载 伪造
    $("#DownLoad").click(function () {
        try {
            PicShadowFlag = false;
            var dom = $(".Videos .VideoList").not(".VideoDisabled");
            for (var i = 0, max = dom.length; i < max; i++) {
                $($(dom[i]).find(".DownVideo")[0]).get(0).click(); //模拟点击
            }
        }
        catch (ex) {
            addLeftMsg("e", chrome.i18n.getMessage("txt_ErrorTryAgain"));
            PicShadowFlag = true;
        }
        PicShadowFlag = true;
    });
    //全部下载 伪造
    $("#DownLoad_Default").click(function () {
        try {
            PicShadowFlag = false;
            var dom = $(".Videos .VideoList").not(".VideoDisabled");
            for (var i = 0, max = dom.length; i < max; i++) {
                $($(dom[i]).find(".DownVideo_Default")[0]).get(0).click(); //模拟点击
            }
        }
        catch (ex) {
            addLeftMsg("e", chrome.i18n.getMessage("txt_ErrorTryAgain"));
            PicShadowFlag = true;
        }
        PicShadowFlag = true;
    });
});

var PlayPreViewUrl = "";
//开始播放
function PlayPreView(url, referer) {
    $(".PreView").show();
    var video = $("#VideoPreView")[0];
    if (referer != undefined) {
        chrome.extension.sendMessage({ order: "I want to play this video", Resquest: { url: url, referer: referer } });
        PlayPreViewUrl = url;
    }
    video.src = url;
    video.play();
    setTimeout(checkVideo, 1000 * 5, "");
    addLeftMsg("i", chrome.i18n.getMessage("DOWNVIDEO_js_txt_ClickClose"));
}
//停止播放
function ClosePreView() {
    $(".PreView").hide();
    var video = $("#VideoPreView")[0];
    video.pause();
    video.src = "";
    removeLeftMsg();//移除提示信息
    if (PlayPreViewUrl != "") {
        chrome.extension.sendMessage({ order: "I wantnot to play this video", url: PlayPreViewUrl });
        PlayPreViewUrl = "";
    }
}


function checkVideo(ex) {
    var video = $("#VideoPreView")[0];
    switch (video.error.code) {
        case 1: { addLeftMsg("e", chrome.i18n.getMessage("DOWNVIDEO_js_txt_VideoError1")); break; }
        case 2: { addLeftMsg("e", chrome.i18n.getMessage("DOWNVIDEO_js_txt_VideoError2")); break; }
        case 3: { addLeftMsg("e", chrome.i18n.getMessage("DOWNVIDEO_js_txt_VideoError3")); break; }
        case 4: { addLeftMsg("e", chrome.i18n.getMessage("DOWNVIDEO_js_txt_VideoError4")); break; }
    }
}








//function showPreView(url, referer) {
//    $(".PreView").show();
//    addLeftMsg("i", "点击视频外区域关闭播放");
//    //新建一个 MediaSource 对象，并且把 mediaSource 作为 objectURL 附加到 video 标签上
//    var video = $("#VideoPreView")[0];
//    var mediaSource =new MediaSource();
//    video.src =URL.createObjectURL(mediaSource);  
//    //接下来就可以监听 mediaSource 上的 sourceOpen 事件，并且设置一个回调：
//    mediaSource.addEventListener('sourceopen', function () {
//        var sourceBuffer = mediaSource.addSourceBuffer('video/mp4; codecs="avc1.42E01E, mp4a.40.2"');
//        fetchBuffer(url, referer, function (buf) {
//            sourceBuffer.appendBuffer(buf);
//            //sourceBuffer.addEventListener('updateend', function () {
//            //    //mediaSource.endOfStream();
//            //    video.play();
//            //});
//        });
//    });
//}

//function fetchBuffer(url, referer, cb) {
//    var xhr =new XMLHttpRequest();
//    xhr.open('get', url, true);
//    xhr.responseType = 'arraybuffer';
//    xhr.setRequestHeader('DownLoadType', 'KazusaToolDownLoad');
//    xhr.setRequestHeader('DownLoadTypeReferer', referer);
//    xhr.onload = function () { cb(xhr.response) };
//    xhr.send();

//    //var xhr =new XMLHttpRequest();
//    //xhr.open('get', url);
//    //xhr.responseType = 'blob';
//    //xhr.setRequestHeader('DownLoadType', 'KazusaToolDownLoad');
//    //xhr.setRequestHeader('DownLoadTypeReferer', referer);
//    //xhr.onload = function (e) {
//    //    console.log(e);
//    //    console.log(xhr.response);
//    //};
//    //xhr.send();
//};