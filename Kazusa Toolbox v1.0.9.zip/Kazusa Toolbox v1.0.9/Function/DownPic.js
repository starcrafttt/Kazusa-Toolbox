﻿//发送信息 获取background 中的 所有图片链接
chrome.extension.sendMessage({ order: "getPagePictoSaveArr" }, function (response) {
    if (response.arr) {
        var array = response.arr;
        var html = "<div class=\"PicBlock\" tag=\"{index}\">" +
                            "<img src=\"../Img/snowflake.png\" tag=\"{index}\"/>" +
                            "<a class=\"DownPic\" tag=\"{index}\" data-url=\"{url}\" data-referer=\"{referer}\" download=\"{littleurl}\">" + chrome.i18n.getMessage("txt_DownLoad") + "</a>" +
                            "<div class='PicShadow'><table style='width: 100%;height: 100%;color: #f00;'><tbody><tr><td>X</td></tr></tbody></table></div>" +
                            "<div class='size' tag=\"{index}\"></div>" +
                            "<div class='type' tag=\"{index}\"></div>" +
                            "<a class=\"see\" tag=\"{index}\" href=\"{url}\"  target=\"_blank\">" + chrome.i18n.getMessage("DOWNPIC_js_txt_See") + "</a>" +
                        "</div>";
        $(".allNum").text(array.length);    //总数
        var temphtml = "";
        //先生成体积
        for (var i = 0, max = array.length; i < max; i++) {
            if (array[i] != null && array[i] != undefined && array[i] != "") {
                var nowUrl = array[i].nowUrl;   //真实url
                var referer = array[i].referer;   //refererUrl
                var little = nowUrl.split('/');
                temphtml += html.replace(/{index}/g, i).replace(/{url}/g, nowUrl).replace(/{referer}/g, referer).replace(/{littleurl}/g, little[little.length - 1]);
            }
        }
        $(".Pics").append(temphtml);
        //创建缩略图
        for (var i = 0, max = array.length; i < max; i++) {
            if (array[i] != null && array[i] != undefined && array[i] != "") {
                var nowUrl = array[i].nowUrl;   //真实url
                var referer = array[i].referer;   //refererUrl
                resizeImage(nowUrl, $("img[tag='" + i + "']"), 200, 200);
            }
        }

        //小于100个 才添加css animation效果 
        if (array.length <= 100) {
            //----css 延迟
            var dom = $(".PicBlock");
            var delay = 0.05;
            for (var i = 0, max = dom.length; i < max; i++) {
                $($(dom)[i]).css("animation-delay", delay + "s");
                delay += 0.01;
            }
            //---css 延迟
        }
        else {
            $(".PicBlock").css("animation", "none");
            $(".PicBlock").css("opacity", "1");
        }

        $(".PicBlock img").on('error', function () {
            $(this).parent('.PicBlock').addClass('PicNone');    //error直接显示 X
        });

        //点击添加叉号遮罩
        $(".PicBlock").click(function () {
            if (PicShadowFlag) {
                $(this).toggleClass("PicNone");
                getNowNum();//统计总数
            }
            else {
                PicShadowFlag = true;
            }
        });
        //锁事件冒泡
        $(".DownPic").click(function () {
            PicShadowFlag = false;
        });
        //锁事件冒泡
        $(".see").click(function () {
            PicShadowFlag = false;
        });

        $(".DownPic").click(function () {

            var downloadUrl = $(this).attr("data-url");
            var downloadName = $(this).attr("download");
            var downloadReferer = $(this).attr("data-referer");
            var Folder = downMainFolder + downloadName;
            //var Folder = downloadName;
            //下载
            console.log(downloadName);
            chrome.downloads.download({
                url: downloadUrl,  //下载的url
                filename: Folder,  //保存的文件名
                conflictAction: "uniquify",  //重名文件的处理方式 //只能为uniquify(在文件名后面添加带括号的序号，以保证文件名唯一)，overwrite(覆盖)或者 prompt(给出提示，让用户自行决定是对文件进行重命名还是将其覆盖、)
                saveAs: false,  //是否弹出另存为窗口
                headers: [{ name: "DownLoadType", value: "KazusaToolDownLoad" }, { name: "DownLoadTypeReferer", value: downloadReferer }],  //自定义header数组 [object,object,object]  object--> { name:"Referer",value:"urlxxxxxxxxxxxx"}
            }, function (downloadId) {
                if (downloadId != undefined) {
                    addLeftMsg("s", chrome.i18n.getMessage("txt_CreateDownLoad_Success") + downloadId);
                }
                else {
                    addLeftMsg("e", chrome.i18n.getMessage("txt_CreateDownLoad_Error"));
                }
            });


        });
        //统计总数
        getNowNum();

    }
});
var nowDate = new Date();
var downMainFolder = "";
var PicShadowFlag = true;   //用来锁事件冒泡   event.stopPropagation(); 无效了
$(document).ready(function (e) {
    downMainFolder = chrome.i18n.getMessage("manifestName") + " PicDownLoad [" + nowDate.getFullYear() + "-" + (parseInt(nowDate.getMonth()) + 1) + "-" + nowDate.getDate() + " " + nowDate.getHours() + "_" + nowDate.getMinutes() + "_" + nowDate.getSeconds() + "]/";

    //下载
    $("#DownLoad").click(function () {
        try {
            PicShadowFlag = false;
            var dom = $(".Pics .PicBlock").not(".PicNone");
            for (var i = 0, max = dom.length; i < max; i++) {
                $($(dom[i]).find("a")[0]).get(0).click(); //模拟点击
            }
        }
        catch (ex) {
            addLeftMsg("e", chrome.i18n.getMessage("txt_ErrorTryAgain"));
            PicShadowFlag = true;
        }
        PicShadowFlag = true;
    });
    
    //最小宽高 [type='Range'] 的触发函数
    $('#minWidthRange').on('input propertychange', function () {
        $("#minWidth").text($(this).val());
        //然后隐藏小尺寸图片
        HideLittleSizePic();
    });
    //最小宽高 [type='Range'] 的触发函数
    $('#minHeightRange').on('input propertychange', function () {
        $("#minHeight").text($(this).val());
        //然后隐藏小尺寸图片
        HideLittleSizePic();
    });
    
});

//隐藏小尺寸图片
function HideLittleSizePic() {
    var dom = $(".PicBlock");
    for (var i = 0, max = dom.length; i < max; i++) {
        if (parseInt($(dom[i]).attr('data-w')) < parseInt($("#minWidthRange").val()) || parseInt($(dom[i]).attr('data-h')) < parseInt($("#minHeightRange").val())) {
            $(dom[i]).addClass("PicNone");
        }
        else {
            $(dom[i]).removeClass("PicNone");
        }
    }
    //统计个数
    getNowNum();
}
//计算 $(".Pics .PicBlock").not(".PicNone");的量
function getNowNum() {
    var dom = $(".Pics .PicBlock").not(".PicNone");
    $(".nowNum").text(dom.length);
}

//获取缩略图  显示到dom 并显示尺寸 获取 图片文件类型
//src   图片url
//dom  处理完成的图片保存在哪
//w     缩放的尺寸
//h     缩放的尺寸
function resizeImage(src, dom, w, h) {
    var canvas = document.createElement("canvas");
    var ctx = canvas.getContext("2d");
    var im = new Image();
    w = w || 0;
    h = h || 0;
    im.onload = function () {
        //未传入缩放尺寸用原尺寸
        !w && (w = this.width);
        !h && (h = this.height);
        if (this.width < w && this.height < h)
        {
            //原尺寸比切割尺寸小的话  取原尺寸
            w = this.width;
            h = this.height;
        }
        else if (w !== this.width || h !== this.height) {
            //以长宽最大值作为最终生成图片的依据
            var ratio;//比例
            if (w > h) {
                ratio = this.width / w;
                h = this.height / ratio;
            } else if (w === h) {
                if (this.width > this.height) {
                    ratio = this.width / w;
                    h = this.height / ratio;
                } else {
                    ratio = this.height / h;
                    w = this.width / ratio;
                }
            } else {
                ratio = this.height / h;
                w = this.width / ratio;
            }
        }

        //以传入的长宽作为最终生成图片的尺寸【暂时不需要这种功能】
        //if (w > h) {
        //    var offset = (w - h) / 2;
        //    canvas.width =w
        //    canvas.height = h;
        //    ctx.drawImage(im, 0, 0, w, h);
        //    //canvas.width = canvas.height = w;
        //    //ctx.drawImage(im, 0, offset, w, h);   //为了补充 透明白边 时 图片居中
        //} else if (w < h) {
        //    var offset = (h - w) / 2;
        //    canvas.width = w
        //    canvas.height = h;
        //    ctx.drawImage(im, 0, 0, w, h);
        //    //canvas.width = canvas.height = h;
        //    //ctx.drawImage(im, offset, 0, w, h);
        //} else {
        //    canvas.width = w
        //    canvas.height = h;
        //    //canvas.width = canvas.height = h;
        //    ctx.drawImage(im, 0, 0, w, h);
        //}

        canvas.width = w
        canvas.height = h;
        ctx.drawImage(im, 0, 0, w, h);

        dom.attr("src", canvas.toDataURL("image/png")); //展示图片

        var target = dom.attr('tag');
        $(".size[tag='" + target + "']").text(this.width + "*" + this.height);//并保存尺寸
        $(".PicBlock[tag='" + target + "']").attr("data-w", this.width);
        $(".PicBlock[tag='" + target + "']").attr("data-h", this.height);

        if (this.src.indexOf(";base64,") == -1) {
            var srd = this.src.split("?")[0].split(".");
            var lastName = srd[srd.length - 1].toLowerCase();   //后缀名
            var lastNames = ["bmp", "pcx", "tiff", "gif", "jpeg", "jpg",
                                      "tga", "exif", "fpx", "svg", "psd", "cdr",
                                      "dxf", "ufo", "eps", "ai", "png", "pcd",
                                      "hdri", "raw", "wmf", "flic", "emf", "ico","webp"];
            if (lastNames.indexOf(lastName) != -1) {
                $(".type[tag='" + target + "']").text(lastName);           //类型
            }
            else {
                $(".type[tag='" + target + "']").text(chrome.i18n.getMessage("txt_unKnow"));
            }
        }
        else {
            var type = this.src.split("data:image/")[1].split(";base64,")[0];
            $(".type[tag='" + target + "']").text(type);
        }
    }
    im.src = src;
}