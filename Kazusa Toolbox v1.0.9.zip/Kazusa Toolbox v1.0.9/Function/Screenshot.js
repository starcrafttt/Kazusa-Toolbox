﻿chrome.extension.sendMessage({ order: "getScreenshot" }, function (response) {
    if (response.Screenshot) {

        //展示
        $("#ScreenshotPic").attr("src", response.Screenshot);

        var now = new Date();
        var aaaa = now.getFullYear() + "-" + parseInt(now.getMonth()+1) + "-" + now.getDate() + "-" + now.getHours() + "-" + now.getMinutes() + "-" + now.getSeconds();
        //下载按钮
        $("#DownLoadPic").attr("href", response.Screenshot);
        $("#DownLoadPic").attr("download", "Screenshot-" + aaaa+".png");
    }
});


$(document).ready(function () {
    $("#DownLoad").click(function () {
        $('#DownLoadPic').get(0).click();
    });
});